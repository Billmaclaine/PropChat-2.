#!/usr/bin/env python3
import subprocess
subprocess.check_call(["python","-m","pip","install","kivy-ios"])
subprocess.check_call(["toolchain","build","python3","kivy","requests"])
subprocess.check_call(["toolchain","create","PropChat","../propchat"])
print("Open the generated Xcode project, configure signing/team and build for iPhone/iPad.")
