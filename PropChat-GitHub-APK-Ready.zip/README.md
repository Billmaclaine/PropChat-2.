# PropChat v1.1 — Python Android + iOS Integrated Build

A cross-platform Python/Kivy client paired with a Python/FastAPI realtime backend.

## Implemented
- Native Python/Kivy client UI with Apple-inspired styling
- Android Buildozer configuration
- iOS kivy-ios/Xcode build script
- JWT login/register foundation
- WebSocket realtime chat transport
- Ciphertext-envelope message API (server never decrypts message bodies)
- Media upload endpoint with SHA-256 integrity metadata
- Status create/list endpoints
- WebRTC signaling relay over WebSocket
- Call invite/accept/offer/answer/ICE/hangup event routing
- Device identity/key-bundle API boundary for production Signal/libsignal integration
- SQLite development store; deployment can swap to PostgreSQL
- Permissions configuration for camera, microphone, notifications and media

## Run backend
cd server
python -m venv .venv
# activate .venv
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000

## Run client desktop
cd propchat
pip install -r requirements.txt
PROPCHAT_API=http://127.0.0.1:8000 python main.py

## Android
Build on Linux/macOS with Buildozer:
`buildozer android debug`

## iOS
On macOS:
`python scripts/build_ios.py`
Then open the generated Xcode project, set Team/signing, and build/archive.

## Security
The transport only accepts opaque protocol envelopes. The project deliberately does NOT implement a custom cryptographic ratchet. For production E2EE, integrate a maintained native Signal/libsignal implementation and persist identity/pre-key/session state securely in Android Keystore/iOS Keychain. Media must be encrypted on-device before upload, with its key delivered through the established E2EE session.

## Calls
The backend implements signaling, not the media codec itself. The native client exposes the signaling state machine. A production Android/iOS release should link a native WebRTC SDK (or a maintained Python bridge) for actual microphone/camera media. TURN is required for reliable connectivity across restrictive NATs.
