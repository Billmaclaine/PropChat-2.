[app]
title = PropChat
package.name = propchat
package.domain = com.propchat
source.dir = propchat
source.include_exts = py,kv,png,jpg,jpeg,json
version = 1.1.0
requirements = python3,kivy,requests,websocket-client
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,CAMERA,RECORD_AUDIO,POST_NOTIFICATIONS,READ_MEDIA_IMAGES,READ_MEDIA_VIDEO
android.api = 35
android.minapi = 23
