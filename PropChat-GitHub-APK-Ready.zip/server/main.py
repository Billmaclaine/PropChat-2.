import os, time, uuid, hashlib
from pathlib import Path
from typing import Optional
import jwt
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, UploadFile, File, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

SECRET = os.getenv("PROPCHAT_SECRET", "replace-this-secret")
MEDIA = Path(os.getenv("PROPCHAT_MEDIA", "./media")); MEDIA.mkdir(parents=True, exist_ok=True)
app = FastAPI(title="PropChat API", version="1.1")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
users, messages, statuses, devices = {}, [], [], {}
connections = {}  # user_id -> set[WebSocket]

def make_token(uid): return jwt.encode({"sub": uid, "iat": int(time.time())}, SECRET, algorithm="HS256")
def uid_from_token(token):
    try: return jwt.decode(token, SECRET, algorithms=["HS256"])["sub"]
    except Exception: raise HTTPException(401, "Invalid token")

def bearer(auth):
    if not auth or not auth.startswith("Bearer "): raise HTTPException(401, "Bearer token required")
    return uid_from_token(auth[7:])

class Auth(BaseModel): username: str; password: str
class Message(BaseModel): recipient_id: str; envelope: dict
class Status(BaseModel): media_id: str; caption: str = ""
class Device(BaseModel): device_id: str; registration_id: int; identity_key: str; signed_prekey: dict; one_time_prekeys: list[str] = []

@app.get("/health")
def health(): return {"ok": True, "version": "1.1"}

@app.post("/auth/register")
def register(x: Auth):
    if x.username in users: raise HTTPException(409, "Username already exists")
    uid = str(uuid.uuid4()); users[x.username] = {"id": uid, "password": x.password}
    return {"user_id": uid, "token": make_token(uid)}

@app.post("/auth/login")
def login(x: Auth):
    u = users.get(x.username)
    if not u or u["password"] != x.password: raise HTTPException(401, "Invalid credentials")
    return {"user_id": u["id"], "token": make_token(u["id"])}

@app.post("/devices")
def register_device(x: Device, authorization: Optional[str] = Header(None)):
    uid = bearer(authorization); devices[(uid, x.device_id)] = x.model_dump(); return {"ok": True}

@app.get("/devices/{user_id}")
def get_devices(user_id: str):
    return [{"device_id": k[1], **v} for k,v in devices.items() if k[0] == user_id]

@app.post("/messages")
async def send_message(x: Message, authorization: Optional[str] = Header(None)):
    sender = bearer(authorization)
    item = {"id": str(uuid.uuid4()), "sender_id": sender, "recipient_id": x.recipient_id,
            "envelope": x.envelope, "created_at": int(time.time())}
    messages.append(item); await fanout(x.recipient_id, {"type":"message", "data":item})
    return item

@app.post("/media")
async def upload_media(file: UploadFile = File(...), authorization: Optional[str] = Header(None)):
    uid = bearer(authorization); data = await file.read()
    mid = str(uuid.uuid4()); suffix = Path(file.filename or "").suffix[:12]
    path = MEDIA / (mid + suffix); path.write_bytes(data)
    return {"media_id": mid, "owner_id": uid, "sha256": hashlib.sha256(data).hexdigest(), "filename": file.filename, "content_type": file.content_type}

@app.post("/status")
async def create_status(x: Status, authorization: Optional[str] = Header(None)):
    uid = bearer(authorization); item={"id":str(uuid.uuid4()),"user_id":uid,"media_id":x.media_id,"caption":x.caption,"created_at":int(time.time())}
    statuses.append(item); return item

@app.get("/status")
def list_status(): return statuses[-200:]

async def fanout(uid, payload):
    for ws in list(connections.get(uid, set())):
        try: await ws.send_json(payload)
        except Exception: connections[uid].discard(ws)

@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket, token: str):
    uid = uid_from_token(token); await ws.accept(); connections.setdefault(uid,set()).add(ws)
    try:
        while True:
            data = await ws.receive_json()
            # Signaling relay: call messages are routed without inspecting SDP/ICE contents.
            target = data.get("to")
            if target: await fanout(target, {**data, "from": uid})
    except WebSocketDisconnect:
        connections.get(uid,set()).discard(ws)
