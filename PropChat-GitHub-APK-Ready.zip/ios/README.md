# iOS build
Run `python scripts/build_ios.py` on macOS. Xcode is required for signing and device/App Store builds.

For production E2EE, store identity/session keys in Keychain. For production calls, link a maintained native WebRTC framework through an iOS bridge; the backend WebSocket remains signaling-only.
