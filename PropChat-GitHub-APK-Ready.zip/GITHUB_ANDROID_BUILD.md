# Build PropChat APK on GitHub

1. Upload the contents of this project to a GitHub repository.
2. Commit the files to the `main` branch.
3. GitHub Actions will automatically run **Build PropChat Android APK**.
4. When the workflow is green, open the workflow run and download the `PropChat-Android-APK` artifact.

You can also start a build manually from the repository's **Actions** tab using **Run workflow**.

## Important

The APK is a client application. The current source uses `http://127.0.0.1:8000` as its development API default. For two phones to communicate over the internet, the PropChat FastAPI server must be deployed to a reachable HTTPS/WSS address and the client API endpoint must be configured accordingly.
