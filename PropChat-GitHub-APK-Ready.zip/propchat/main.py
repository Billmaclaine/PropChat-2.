import os, json, threading, requests
import websocket
from kivy.app import App
from kivy.lang import Builder
from kivy.properties import StringProperty
from kivy.clock import Clock
from kivy.uix.screenmanager import Screen

API = os.getenv("PROPCHAT_API", "http://127.0.0.1:8000")
TOKEN = ""; USER_ID = ""

KV = r'''
#:import dp kivy.metrics.dp
ScreenManager:
    LoginScreen:
    HomeScreen:
    ChatScreen:
    StatusScreen:
    CallsScreen:
<LoginScreen>:
    name: "login"
    BoxLayout:
        orientation: "vertical"; padding: dp(28); spacing: dp(14)
        Label: text: "PropChat"; font_size: "34sp"; bold: True; color: .06,.06,.08,1
        Label: text: "Private messaging, reimagined for mobile."; color: .4,.4,.45,1
        TextInput: id:u; hint_text:"Username"; multiline:False; size_hint_y:None; height:dp(48)
        TextInput: id:p; hint_text:"Password"; password:True; multiline:False; size_hint_y:None; height:dp(48)
        Button: text:"Sign in / Create account"; size_hint_y:None; height:dp(52); on_release:root.login(u.text,p.text)
        Label: text:root.error; color:.8,.1,.1,1
<HomeScreen>:
    name:"home"
    BoxLayout:
        orientation:"vertical"
        Label: text:"PropChat"; font_size:"30sp"; bold:True; size_hint_y:None; height:dp(65)
        Button: text:"Messages"; on_release:app.root.current="chat"
        Button: text:"Status"; on_release:app.root.current="status"
        Button: text:"Calls"; on_release:app.root.current="calls"
        Label: text:"Realtime • encrypted-envelope transport"; color:.4,.4,.45,1
<ChatScreen>:
    name:"chat"
    BoxLayout:
        orientation:"vertical"
        BoxLayout: size_hint_y:None; height:dp(55)
            Button: text:"‹"; size_hint_x:.2; on_release:app.root.current="home"
            Label: text:"Messages"; bold:True
        TextInput: id:rid; hint_text:"Recipient user ID"; multiline:False; size_hint_y:None; height:dp(45)
        TextInput: id:msg; hint_text:"Encrypted message payload"; multiline:False; size_hint_y:None; height:dp(45)
        Button: text:"Send"; size_hint_y:None; height:dp(50); on_release:root.send(rid.text,msg.text)
        ScrollView:
            Label: id:log; text:root.log; text_size:self.width,None; size_hint_y:None; height:self.texture_size[1]
<StatusScreen>:
    name:"status"
    BoxLayout:
        orientation:"vertical"; padding:dp(20); spacing:dp(12)
        Label: text:"Status"; font_size:"28sp"; bold:True
        Label: text:"Photo/video status uses /media then /status."
        Button: text:"Back"; on_release:app.root.current="home"
<CallsScreen>:
    name:"calls"
    BoxLayout:
        orientation:"vertical"; padding:dp(20); spacing:dp(12)
        Label: text:"Calls"; font_size:"28sp"; bold:True
        Label: text:"WebRTC signaling is integrated with the realtime channel. Native WebRTC media must be linked for production audio/video."
        Button: text:"Back"; on_release:app.root.current="home"
'''

class LoginScreen(Screen):
    error=StringProperty("")
    def login(self,u,p):
        global TOKEN,USER_ID
        try:
            r=requests.post(API+"/auth/login",json={"username":u,"password":p},timeout=10)
            if r.status_code==401: r=requests.post(API+"/auth/register",json={"username":u,"password":p},timeout=10)
            r.raise_for_status(); data=r.json(); TOKEN=data["token"]; USER_ID=data["user_id"]
            App.get_running_app().root.current="home"; threading.Thread(target=self.listen,daemon=True).start()
        except Exception as e: self.error=str(e)
    def listen(self):
        try:
            url=API.replace("https://","wss://").replace("http://","ws://")+"/ws?token="+TOKEN
            sock=websocket.create_connection(url)
            while True:
                event=json.loads(sock.recv())
                Clock.schedule_once(lambda dt,e=event: App.get_running_app().root.get_screen("chat").append(e))
        except Exception as e:
            Clock.schedule_once(lambda dt: setattr(App.get_running_app().root.get_screen("chat"),"log", "Realtime disconnected"))

class ChatScreen(Screen):
    log=StringProperty("")
    def append(self,e): self.log += "\n"+json.dumps(e,indent=2)
    def send(self,rid,msg):
        envelope={"protocol":"signal","version":1,"ciphertext":msg}
        try:
            r=requests.post(API+"/messages",json={"recipient_id":rid,"envelope":envelope},headers={"Authorization":"Bearer "+TOKEN},timeout=10)
            self.append(r.json())
        except Exception as e:self.append({"error":str(e)})
class StatusScreen(Screen): pass
class CallsScreen(Screen): pass
class PropChatApp(App):
    def build(self): return Builder.load_string(KV)
PropChatApp().run()
